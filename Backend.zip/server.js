require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { sequelize } = require('./models');
const cors = require('cors');

const app = express();

// 2. Configure CORS
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3008', // Allow your frontend origin
    credentials: true                // Required if using sessions/cookies/passport
}));
app.use(bodyParser.json());
app.use(express.static('web'));

app.use('/api/sms', require('./routes/sms.routes'));
app.use('/api/device', require('./routes/device.routes'));
app.use('/admin', require('./routes/admin.routes'));
app.use('/auth', require('./routes/auth.routes'));
app.use('/api/user', require('./routes/user.routes'));
app.use('/api/dashboard', require('./routes/dashboard.routes'));
require('./config/passport');



sequelize.sync({}).then(() => {
    app.listen(process.env.PORT, () =>
        console.log(`SMS Gateway running on ${process.env.PORT}`)
    );
});
